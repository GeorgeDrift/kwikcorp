
import React from 'react';
import { LayoutGrid, BarChart3, Info, ClipboardCheck, Zap, ShieldCheck, TrendingUp, Leaf, Users, ShoppingCart, Truck } from 'lucide-react';
import { Service, Value } from './types';

export const IMAGES = {
  hero: "https://scontent.fblz1-1.fna.fbcdn.net/v/t39.30808-6/603059749_122094201393187259_5574990911414127814_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=6ee11a&oh=00_AfozxBJ-mrF2SfrURWYOhjc3iSN1XmfInVk1E9C2D5z50Q&oe=69618A02",
  about: "https://scontent.fblz1-1.fna.fbcdn.net/v/t39.30808-6/597929091_122111674929110076_2631308179868286230_n.jpg?stp=dst-jpg_p526x296_tt6&_nc_cat=107&ccb=1-7&oh=00_AfriORSYGXg4WYmPoS8nrCPuLtclmifTzjTt-q38QIqxTg&oe=69617637",
  logo: "https://scontent.fblz1-1.fna.fbcdn.net/v/t39.30808-1/603906831_122112186855110076_4671615196328986640_n.jpg?stp=dst-jpg_s200x200_tt6&_nc_cat=111&ccb=1-7&oh=00_Afr-_vsLzK3o37tekW6IjqbETPLPrw4wmQRnWoP2XEkVZQ&oe=69618D8A"
};

export const CORE_VALUES: Value[] = [
  { title: "Innovation", description: "Leveraging modern digital tools to solve real agricultural challenges.", icon: "Zap" },
  { title: "Integrity", description: "Building trust through transparency, reliability, and ethical conduct.", icon: "ShieldCheck" },
  { title: "Efficiency", description: "Delivering solutions that save time, reduce costs, and improve outcomes.", icon: "TrendingUp" },
  { title: "Sustainability", description: "Supporting environmentally and economically sustainable agriculture.", icon: "Leaf" },
  { title: "Collaboration", description: "Working closely with farmers, partners, and institutions.", icon: "Users" }
];

export const SERVICES: Service[] = [
  {
    id: "agri-ecommerce",
    title: "Agri Ecommerce",
    shortDescription: "A specialized digital marketplace providing farmers with direct access to high-quality inputs, seeds, and equipment.",
    whoItsFor: "Farmers, input suppliers, and agricultural retail agribusinesses.",
    keyBenefits: ["Lower input costs", "Direct access to suppliers", "Secure digital payments"],
    icon: "ShoppingCart"
  },
  {
    id: "agri-courier",
    title: "Agri Courier & Logistics",
    shortDescription: "Efficient logistics solutions designed to move farm produce from rural areas to urban and regional markets rapidly.",
    whoItsFor: "Commercial farmers, cooperatives, and produce wholesalers.",
    keyBenefits: ["Reduced post-harvest loss", "Timely delivery", "Real-time tracking"],
    icon: "Truck"
  },
  {
    id: "farm-mgmt",
    title: "Digital Farm Management",
    shortDescription: "Digital tools to help manage operations such as crop planning, input usage, and record-keeping.",
    whoItsFor: "Smallholder farmers and commercial operators.",
    keyBenefits: ["Improved planning", "Tracking of inputs", "Operational efficiency"],
    icon: "LayoutGrid"
  },
  {
    id: "data-analytics",
    title: "Data Collection & Analytics",
    shortDescription: "Analysis of agricultural data to support informed decision-making and performance monitoring.",
    whoItsFor: "Farmers, cooperatives, NGOs, and development projects.",
    keyBenefits: ["Data-driven insights", "Productivity assessment", "Evidence-based planning"],
    icon: "BarChart3"
  }
];
