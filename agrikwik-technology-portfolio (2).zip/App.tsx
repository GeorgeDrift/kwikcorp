
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MissionVision from './components/MissionVision';
import Story from './components/Story';
import Services from './components/Services';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';
import AdminDashboard from './components/AdminDashboard';
import { SERVICES, IMAGES } from './constants';
import { SiteContent } from './types';
import { ApiService } from './services/api';

const App: React.FC = () => {
  const [view, setView] = useState<'public' | 'admin'>('public');
  const [isScrolled, setIsScrolled] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const [content, setContent] = useState<SiteContent>({
    mission: "To enhance agricultural efficiency through innovative digital solutions.",
    vision: "To become a leading agritech solution provider.",
    story: "AgriKwik aims to bridge the gap between tradition and technology.",
    images: {
      hero: IMAGES.hero,
      about: IMAGES.about,
      logo: IMAGES.logo,
      sectionBg: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2"
    },
    services: SERVICES,
    gallery: [
      { id: '1', url: IMAGES.hero, title: "Agri Innovation", category: "Innovation" },
      { id: '2', url: IMAGES.about, title: "Company Milestone", category: "Success" }
    ]
  });

  useEffect(() => {
    const fetchData = async () => {
      const data = await ApiService.getContent();
      if (data) setContent(data);
      setLoading(false);
    };

    const handleHashChange = () => {
      if (window.location.hash === '#manage' || window.location.hash === '#admin') {
        setView('admin');
      } else {
        setView('public');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    fetchData();

    if (view === 'public') {
      ApiService.logVisit(navigator.userAgent);
    }

    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('scroll', handleScroll);
    };
  }, [view]);

  // Fix: Removed call to non-existent ApiService.updateContent on line 73.
  // The backend uses granular updates via AdminDashboard, and the main site re-fetches content on view change.
  const updateContent = async (newContent: SiteContent, password?: string) => {
    setContent(newContent);
  };

  const [clickCount, setClickCount] = useState(0);
  const handleLogoClick = () => {
    setClickCount(prev => prev + 1);
    if (clickCount >= 3) {
      window.location.hash = '#manage';
      setClickCount(0);
    }
    setTimeout(() => setClickCount(0), 1000);
  };

  if (loading) return <div className="h-screen flex items-center justify-center bg-slate-50 text-green-600 font-bold">Loading AgriKwik Profile...</div>;

  if (view === 'admin') {
    return <AdminDashboard onExit={() => { window.location.hash = ''; setView('public'); }} content={content} onUpdate={updateContent} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-jakarta">
      <Navbar isScrolled={isScrolled} logoUrl={content.images.logo} onLogoClick={handleLogoClick} />
      
      <main className="flex-grow">
        <section id="home">
          <Hero heroImage={content.images.hero} />
        </section>
        
        <div className="relative">
          <div className="absolute inset-0 opacity-[0.05] pointer-events-none z-0 overflow-hidden">
            <img src={content.images.sectionBg} className="w-full h-full object-cover" alt="" />
          </div>
          
          <div className="relative z-10">
            <section id="mission">
              <MissionVision mission={content.mission} vision={content.vision} />
            </section>
            
            <section id="about" className="bg-white/80 backdrop-blur-sm">
              <Story storyText={content.story} aboutImage={content.images.about} />
            </section>
            
            <section id="services">
              <Services services={content.services} />
            </section>

            <section id="gallery" className="bg-white/80 backdrop-blur-sm">
              <Gallery items={content.gallery} />
            </section>
            
            <section id="contact">
              <Contact bgImage={content.images.sectionBg} />
            </section>
          </div>
        </div>
      </main>

      <Footer logoUrl={content.images.logo} />
      <Chatbot />
    </div>
  );
};

export default App;
