
import React, { useState } from 'react';
import { Mail, MapPin, Send, Facebook, Linkedin } from 'lucide-react';
import { ApiService } from '../services/api';

interface ContactProps {
  bgImage: string;
}

const Contact: React.FC<ContactProps> = ({ bgImage }) => {
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || isSubmitting) return;

    setIsSubmitting(true);
    const success = await ApiService.postMessage(message);
    
    if (success) {
      setIsSent(true);
      setMessage('');
    }
    setIsSubmitting(false);
    
    setTimeout(() => setIsSent(false), 5000);
  };

  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row relative">
          
          <div className="absolute inset-0 opacity-10 pointer-events-none">
             <img src={bgImage} className="w-full h-full object-cover" alt="" />
          </div>

          {/* Info Side */}
          <div className="lg:w-2/5 bg-green-600 p-10 md:p-16 text-white relative z-10">
            <h3 className="text-3xl font-bold mb-6">Connect With Admin</h3>
            <p className="text-green-100 mb-12 text-lg">
              Your message goes directly to our operational team. Let us know how we can support your agricultural project.
            </p>

            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Mail size={24} />
                </div>
                <div>
                  <p className="text-sm text-green-200 uppercase tracking-widest font-bold mb-1">Direct Line</p>
                  <p className="text-lg">support@agrikwik.com</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="text-sm text-green-200 uppercase tracking-widest font-bold mb-1">Our Base</p>
                  <p className="text-lg">Lilongwe, Malawi</p>
                </div>
              </div>
            </div>

            <div className="mt-16 flex space-x-4">
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-white/20 transition-colors rounded-lg flex items-center justify-center">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-white/20 transition-colors rounded-lg flex items-center justify-center">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Form Side */}
          <div className="lg:w-3/5 p-10 md:p-16 text-white relative z-10 bg-slate-900/40 backdrop-blur-md">
            {isSent ? (
              <div className="h-full flex flex-col items-center justify-center text-center animate-in zoom-in duration-300">
                <div className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center mb-6">
                  <Send size={32} className="text-white" />
                </div>
                <h4 className="text-2xl font-bold mb-2">Message Sent!</h4>
                <p className="text-slate-400">Our admin team will review your inquiry shortly.</p>
                <button onClick={() => setIsSent(false)} className="mt-8 text-green-500 font-bold hover:underline">Send another message</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <label className="text-sm font-bold text-slate-400 uppercase tracking-widest">Message for Admin</label>
                  <textarea 
                    required
                    rows={8}
                    disabled={isSubmitting}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe your agricultural needs, feedback, or questions for our team..."
                    className="w-full bg-slate-800/50 backdrop-blur-md border border-slate-700 rounded-2xl px-5 py-4 focus:outline-none focus:border-green-500 transition-colors resize-none text-lg leading-relaxed shadow-inner disabled:opacity-50"
                  ></textarea>
                </div>

                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-5 rounded-2xl shadow-xl hover:shadow-green-600/20 transition-all flex items-center justify-center text-lg transform hover:-translate-y-1 active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? 'Sending...' : 'Post to Admin'}
                  <Send size={20} className="ml-3" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
