
import React from 'react';
import { Maximize2, Camera } from 'lucide-react';
import { GalleryItem } from '../types';

interface GalleryProps {
  items: GalleryItem[];
}

const Gallery: React.FC<GalleryProps> = ({ items }) => {
  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-base font-bold text-green-600 tracking-widest uppercase mb-3">Visual Impact</h2>
            <h3 className="text-4xl font-bold text-slate-900 mb-4">Our Work in Focus</h3>
            <p className="text-lg text-slate-600">
              Capturing the essence of digital transformation in Malawi's agricultural landscape.
            </p>
          </div>
          <div className="hidden md:block">
             <div className="inline-flex items-center space-x-2 text-green-600 font-bold border-b-2 border-green-600 pb-1 cursor-pointer hover:text-green-700 hover:border-green-700 transition-colors">
               <Camera size={20} />
               <span>Gallery</span>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 min-h-[400px]">
          {items.map((item, index) => (
            <div 
              key={item.id} 
              className={`relative overflow-hidden rounded-[2rem] group cursor-pointer border border-slate-100 shadow-sm bg-slate-100 ${index === 0 ? 'md:col-span-2 md:row-span-2' : ''}`}
            >
              <img 
                src={item.url} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=1000';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <span className="text-green-400 text-xs font-bold uppercase tracking-widest mb-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  {item.category}
                </span>
                <h4 className="text-white text-2xl font-bold transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500 delay-75">
                  {item.title}
                </h4>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-700 delay-150">
                   <Maximize2 className="text-white/70" size={24} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;
