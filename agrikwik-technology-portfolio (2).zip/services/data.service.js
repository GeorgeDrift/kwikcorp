
import { pool } from '../db.js';

const INITIAL_DATA = {
  mission: "To enhance agricultural efficiency and productivity through innovative digital solutions that empower farmers, agribusinesses, and stakeholders with data-driven tools for smarter decision-making.",
  vision: "To become a leading agritech solution provider in Malawi and beyond, transforming agriculture through accessible technology, operational efficiency, and sustainable practices.",
  story: "AgriKwik is a technology-driven agricultural solutions company focused on improving efficiency across the agricultural value chain through digital innovation.\n\nThe company was founded with the recognition that many farmers and agribusinesses face operational inefficiencies due to limited access to timely data, modern tools, and integrated systems.",
  images: {
    hero: "https://scontent.fblz1-1.fna.fbcdn.net/v/t39.30808-6/603059749_122094201393187259_5574990911414127814_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=6ee11a&oh=00_AfozxBJ-mrF2SfrURWYOhjc3iSN1XmfInVk1E9C2D5z50Q&oe=69618A02",
    about: "https://scontent.fblz1-1.fna.fbcdn.net/v/t39.30808-6/597929091_122111674929110076_2631308179868286230_n.jpg?stp=dst-jpg_p526x296_tt6&_nc_cat=107&ccb=1-7&oh=00_AfriORSYGXg4WYmPoS8nrCPuLtclmifTzjTt-q38QIqxTg&oe=69617637",
    logo: "https://scontent.fblz1-1.fna.fbcdn.net/v/t39.30808-1/603906831_122112186855110076_4671615196328986640_n.jpg?stp=dst-jpg_s200x200_tt6&_nc_cat=111&ccb=1-7&oh=00_Afr-_vsLzK3o37tekW6IjqbETPLPrw4wmQRnWoP2XEkVZQ&oe=69618D8A",
    sectionBg: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=2000"
  }
};

export const DataService = {
  async initDb() {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS site_content (
        id SERIAL PRIMARY KEY,
        mission TEXT,
        vision TEXT,
        story TEXT,
        hero_image TEXT,
        about_image TEXT,
        logo_url TEXT,
        section_bg TEXT
      );
      CREATE TABLE IF NOT EXISTS services (
        id TEXT PRIMARY KEY,
        title TEXT,
        short_description TEXT,
        who_its_for TEXT,
        key_benefits TEXT[],
        icon TEXT,
        sort_order INTEGER
      );
      CREATE TABLE IF NOT EXISTS gallery (
        id SERIAL PRIMARY KEY,
        url TEXT,
        title TEXT,
        category TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        text TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS visits (
        id SERIAL PRIMARY KEY,
        user_agent TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    const count = await pool.query('SELECT count(*) FROM site_content');
    if (count.rows[0].count === '0') {
      await pool.query(
        'INSERT INTO site_content (mission, vision, story, hero_image, about_image, logo_url, section_bg) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        [INITIAL_DATA.mission, INITIAL_DATA.vision, INITIAL_DATA.story, INITIAL_DATA.images.hero, INITIAL_DATA.images.about, INITIAL_DATA.images.logo, INITIAL_DATA.images.sectionBg]
      );
    }
  },

  async getSiteContent() {
    const content = await pool.query('SELECT * FROM site_content LIMIT 1');
    const services = await pool.query('SELECT * FROM services ORDER BY sort_order');
    const gallery = await pool.query('SELECT * FROM gallery ORDER BY created_at DESC');
    
    const row = content.rows[0];
    return {
      mission: row.mission,
      vision: row.vision,
      story: row.story,
      images: {
        hero: row.hero_image,
        about: row.about_image,
        logo: row.logo_url,
        sectionBg: row.section_bg
      },
      services: services.rows.map(s => ({
        id: s.id,
        title: s.title,
        shortDescription: s.short_description,
        whoItsFor: s.who_its_for,
        keyBenefits: s.key_benefits,
        icon: s.icon
      })),
      gallery: gallery.rows
    };
  },

  // Granular Site Content Updates
  async updateMission(text) { return pool.query('UPDATE site_content SET mission=$1 WHERE id=1', [text]); },
  async updateVision(text) { return pool.query('UPDATE site_content SET vision=$1 WHERE id=1', [text]); },
  async updateStory(text) { return pool.query('UPDATE site_content SET story=$1 WHERE id=1', [text]); },
  async updateHeroImage(url) { return pool.query('UPDATE site_content SET hero_image=$1 WHERE id=1', [url]); },
  async updateAboutImage(url) { return pool.query('UPDATE site_content SET about_image=$1 WHERE id=1', [url]); },
  async updateLogoUrl(url) { return pool.query('UPDATE site_content SET logo_url=$1 WHERE id=1', [url]); },
  async updateSectionBg(url) { return pool.query('UPDATE site_content SET section_bg=$1 WHERE id=1', [url]); },

  // Service Management
  async addService(s) {
    return pool.query(
      'INSERT INTO services (id, title, short_description, who_its_for, key_benefits, icon, sort_order) VALUES ($1, $2, $3, $4, $5, $6, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM services))',
      [s.id || `service-${Date.now()}`, s.title, s.shortDescription, s.whoItsFor, s.keyBenefits, s.icon]
    );
  },
  async updateService(id, s) {
    return pool.query(
      'UPDATE services SET title=$1, short_description=$2, who_its_for=$3, key_benefits=$4, icon=$5 WHERE id=$6',
      [s.title, s.shortDescription, s.whoItsFor, s.keyBenefits, s.icon, id]
    );
  },
  async deleteService(id) { return pool.query('DELETE FROM services WHERE id=$1', [id]); },

  // Gallery Management
  async addGalleryItem(url, title, category) {
    return pool.query('INSERT INTO gallery (url, title, category) VALUES ($1, $2, $3)', [url, title, category]);
  },
  async deleteGalleryItem(id) { return pool.query('DELETE FROM gallery WHERE id=$1', [id]); },

  async logVisit(userAgent) { return pool.query('INSERT INTO visits (user_agent) VALUES ($1)', [userAgent]); },
  async saveMessage(text) { return pool.query('INSERT INTO messages (text) VALUES ($1)', [text]); },

  async getAdminStats() {
    const visits = await pool.query('SELECT * FROM visits ORDER BY timestamp DESC LIMIT 100');
    const messages = await pool.query('SELECT * FROM messages ORDER BY timestamp DESC LIMIT 50');
    return { visits: visits.rows, messages: messages.rows };
  }
};
