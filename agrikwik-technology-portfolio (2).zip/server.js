
import express from 'express';
import cors from 'cors';
import apiRoutes from './routes/api.routes.js';
import { DataService } from './services/data.service.js';

const app = express();

app.use(cors());
app.use(express.json());

// Routes
app.use('/api', apiRoutes);

// Health Check
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date() }));

const PORT = process.env.PORT || 3001;

// Startup Sequence
const startServer = async () => {
  try {
    console.log('AgriKwik: Initializing Database...');
    await DataService.initDb();
    
    app.listen(PORT, () => {
      console.log(`
      =========================================
      AGRIKWIK BACKEND OPERATIONAL
      URL:  http://localhost:${PORT}
      ENV:  ${process.env.NODE_ENV || 'development'}
      =========================================
      `);
    });
  } catch (err) {
    console.error('CRITICAL ERROR: Failed to start server', err);
    process.exit(1);
  }
};

startServer();
